require 'spec'
describe "Authentication Module" do

  describe "when user has cookies enabled" do
	  it "the cookie should be dropped on the browser"
	  it "there is no sessionid in the url"
  end

end
