class Fixnum
  def timesTen
    self * 10
  end
end

i = 2
i.timesTen
