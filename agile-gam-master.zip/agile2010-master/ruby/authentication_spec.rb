require 'spec'
describe "Authentication Module" do

  it "should redirect upon invalid authentication" do
  end
  
  describe "when user has cookies enabled" do
	it "the cookie should be dropped on the browser"
  end

end